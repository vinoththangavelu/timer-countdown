// const headingH = document.querySelector("h1");
// headingH.textContent = "outputshowen";

var btn1 = document.getElementById("app");
btn1.addEventListener("click", abcd);

function abcd() {
    var node = document.createElement("LI");
    var textnode = document.createTextNode("Water");
    node.appendChild(textnode);
    document.getElementById("show").appendChild(node);
}

function accelarate() {
    window.onkeypress = function(e) {
        alert("pressed " + String.fromCharCode(e.keyCode));
    }
}

function beforeAccelarate() {
    window.onload = function() {
        accelarate();
    }
}
// beforeAccelarate();

// timer

// creating p tag element
// var creatElementMins = document.createElement("p");
// var creatElementSec = document.createElement("p");

// appending value to p element
// var minsCount = document.createTextNode("2");
// var secnCount = document.createTextNode("10");

// appending both tags and values together
// creatElementMins.appendChild(minsCount);
// creatElementSec.appendChild(secnCount);

// setAttribute for created elements p tag
// creatElementMins.setAttribute('id', 'minutescount');
// creatElementSec.setAttribute('id', 'secondcount');

// get the div and store in variable
// var timer = document.getElementById("timer");

// append the created element to div
// timer.appendChild(creatElementMins);
// timer.appendChild(creatElementSec);
// console.log(timer);

// change String to number values
// var getMintues = document.getElementById("minutescount").innerHTML;
// var getSeconds = document.getElementById("secondcount").innerHTML;

// var MintuesConvertNumber = parseInt(getMintues);
// var secondsConvertNumber = parseInt(getSeconds);

// console.log(typeof MintuesConvertNumber);
// declared here to fetch the value of the element
// var minutesCounter = getMintues;
// var secondsCounter = getSeconds;

// console.log(minutesCounter);

// function secondFunction() {
//     setInterval(function() {
//         secondsCounter--;
//         if (secondsCounter >= 0) {
//             var getSeconds = document.getElementById("secondcount");
//             getSeconds.innerHTML = ": " + secondsCounter;
//         } else if (secondsCounter === 0) {
//             minutesCounter--;

//         }

//     }, 1000, minutesFunction)

// }


// function minutesFunction() {
//     alert('suif');
//     setInterval(function() {

//         minutesCounter--;
//         if (minutesCounter >= 0) {
//             var getMintues = document.getElementById("minutescount");
//             getMintues.innerHTML = minutesCounter;
//         }
//     }, 1000)
// };

// secondFunction();

var secound = 10;
var countDiv = document.getElementById('count_div');
var countDown = setInterval(function() {
    'use setrict';
    secoundPass();
}, 1000);

function secoundPass() {
    'use strict';
    var minutes = Math.floor(secound / 60); // var minutes = 2
    var remSecound = secound % 60; // var remSecound = 0

    if (remSecound == 0) {
        remSecound = '0' + remSecound;
        // console.log("consoled " + remSecound);
    }
    // else {
    //     remSecound = remSecound;
    //     // console.log("consoled else " + remSecound);
    // }

    if (secound < 10) {
        remSecound = '0' + remSecound; // add zero before single digit countdown
    }

    countDiv.innerHTML = minutes + ':' + remSecound;

    if (secound > 0) {
        secound -= 1; //or secound = secound - 1 decrease one secound every 1000 millisecond
    } else {
        clearInterval(countDown); //stop count down timer
        countDiv.innerHTML = 'Times Up!!!!'
    }
}